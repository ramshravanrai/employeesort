﻿using CompForecast.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompForecast.Services
{
    public class EmployeeService
    {
        private readonly string _connString;
        public EmployeeService(string connString)
            => _connString = connString;

        private DataTable ExecSp(string spName, params SqlParameter[] parms)
        {
            using var conn = new SqlConnection(_connString);
            using var cmd = new SqlCommand(spName, conn) { CommandType = CommandType.StoredProcedure };
            cmd.Parameters.AddRange(parms);
            using var da = new SqlDataAdapter(cmd);
            var dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public List<Employee> FilterEmployees(string role = null, string loc = null, bool includeInactive = false)
        {
            var dt = ExecSp("dbo.sp_FilterEmployees",
                new SqlParameter("@RoleName", SqlDbType.VarChar, 100) { Value = (object?)role ?? DBNull.Value },
                new SqlParameter("@LocationName", SqlDbType.VarChar, 100) { Value = (object?)loc ?? DBNull.Value },
                new SqlParameter("@IncludeInactive", SqlDbType.Bit) { Value = includeInactive }
            );
            return dt.AsEnumerable().Select(r => new Employee
            {
                Id = (int)r["employee_id"],
                Name = (string)r["name"],
                Role = (string)r["role_name"],
                Location = (string)r["location_name"],
                Comp = (decimal)r["current_comp_inr"]
            }).ToList();
        }

        public (string location, decimal avg) GetAvgComp(string loc)
        {
            var dt = ExecSp("dbo.sp_CalcAverageCompensation",
                new SqlParameter("@LocationName", loc)
            );
            var row = dt.Rows[0];
            return ((string)row["location_name"], (decimal)row["avg_compensation"]);
        }

        public DataTable GetExperienceDistribution(string groupBy)
            => ExecSp("dbo.sp_GetExperienceDistribution",
                new SqlParameter("@GroupBy", groupBy)
            );

        public DataTable SimulateIncrement(decimal pct)
            => ExecSp("dbo.sp_SimulateIncrement",
                new SqlParameter("@PctIncrement", pct)
            );

        public DataTable ExportFiltered(string role, string loc, bool inclInactive, decimal pct)
            => ExecSp("dbo.sp_ExportFilteredEmployees",
                new SqlParameter("@RoleName", (object?)role ?? DBNull.Value),
                new SqlParameter("@LocationName", (object?)loc ?? DBNull.Value),
                new SqlParameter("@IncludeInactive", (object?)inclInactive),
                new SqlParameter("@PctIncrement", pct)
            );
    }
}
