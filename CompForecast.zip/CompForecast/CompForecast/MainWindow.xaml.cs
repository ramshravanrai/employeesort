﻿using LiveCharts.Wpf;
using LiveCharts;
using System.Data;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CompForecast.Services;

namespace CompForecast
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly EmployeeService _svc;
        public SeriesCollection ExpDistValues { get; set; }
        public string[] ExpDistLabels { get; set; }
        public SeriesCollection CompByLocValues { get; set; }
        public string[] CompByLocLabels { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            _svc = new EmployeeService("Your_Conn_String_Here");
            LoadFilters();
            DataContext = this;
        }

        private void LoadFilters()
        {
            cbRole.ItemsSource = _svc.FilterEmployees().Select(e => e.Role).Distinct();
            cbLocation.ItemsSource = _svc.FilterEmployees().Select(e => e.Location).Distinct();
        }

        private void OnApply(object sender, RoutedEventArgs e)
        {
            var role = cbRole.SelectedItem as string;
            var loc = cbLocation.SelectedItem as string;
            var incl = chkInactive.IsChecked == true;
            var pct = decimal.TryParse(txtPct.Text, out var x) ? x : 0m;

            // 1. Grid
            dgEmployees.ItemsSource = _svc.FilterEmployees(role, loc, incl)
                                          .Select(emp => {
                                              emp.Comp = Math.Round(emp.Comp * (1 + pct / 100), 2);
                                              return emp;
                                          });

            // 2. Comp by Location chart
            var avgByLoc = _svc.FilterEmployees(role, null, incl)
                               .GroupBy(e => e.Location)
                               .Select(g => new { g.Key, Avg = g.Average(e => e.Comp) })
                               .ToList();
            CompByLocLabels = avgByLoc.Select(a => a.Key).ToArray();
            CompByLocValues = new SeriesCollection
          { new ColumnSeries { Values = new ChartValues<decimal>(avgByLoc.Select(a=>a.Avg)) }};

            // 3. Experience distribution
            var dt = _svc.GetExperienceDistribution(null);
            ExpDistLabels = dt.Rows.Cast<DataRow>().Select(r => (string)r["exp_bucket"]).ToArray();
            ExpDistValues = new SeriesCollection
          { new ColumnSeries { Values = new ChartValues<int>(dt.Rows.Cast<DataRow>().Select(r=>(int)r["cnt"])) }};

            // Refresh bindings
            chartCompByLoc.Update(true, true);
            chartExpDist.Update(true, true);
        }

        private void OnExport(object sender, RoutedEventArgs e)
        {
            var role = cbRole.SelectedItem as string;
            var loc = cbLocation.SelectedItem as string;
            var incl = chkInactive.IsChecked == true;
            var pct = decimal.TryParse(txtPct.Text, out var x) ? x : 0m;

            var dt = _svc.ExportFiltered(role, loc, incl, pct);
            var dlg = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "CSV Files|*.csv",
                FileName = "employees.csv"
            };
            if (dlg.ShowDialog() == true)
            {
                using var writer = new StreamWriter(dlg.FileName);
                using var csv = new CsvHelper.CsvWriter(writer, CultureInfo.InvariantCulture);
                foreach (DataColumn col in dt.Columns)
                    csv.WriteField(col.ColumnName);
                csv.NextRecord();
                foreach (DataRow row in dt.Rows)
                {
                    foreach (var val in row.ItemArray)
                        csv.WriteField(val);
                    csv.NextRecord();
                }
                MessageBox.Show("Exported to " + dlg.FileName);
            }
        }
    }
}