CREATE TABLE locations (

location_id INT IDENTITY(1,1) PRIMARY KEY,

location_name VARCHAR(100) NOT NULL UNIQUE

);


